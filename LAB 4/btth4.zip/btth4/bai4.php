<?php
    include "connect.php";
    $sql = "select * from NHANVIEN";
    $result = $connect->query($sql);
    echo "<table border='1' cellspacing='0'>";
    echo "<tr><th>STT</th><th>Mã chi nhánh</th><th>Chức năng</th></tr>";
    if ($result->num_rows > 0)
    {
    while($row = $result->fetch_row())
    {
    echo "<tr>";
    echo"<td>$row[0]</td><td>$row[1]</td><td><a
    href='bai4.php?manhanvien=$row[0]' class='Xoa'>Xóa</a></td>";
    echo "</tr>";
    }
    }
    else
    {
    echo "Không có dòng nào";
    }
    $connect->close();
?>

<?php
    $manhanvien = $_GET['manhanvien'];
    include "connect.php";
    $sql = "DELETE FROM NHANVIEN WHERE MaNhanVien='$manhanvien'"; 
    if ($connect->query($sql) == true) {
        echo "Xóa thành công";
    } else {
        echo "Error deleting record: " . $connect->error;
    }
    $connect->close();
?>