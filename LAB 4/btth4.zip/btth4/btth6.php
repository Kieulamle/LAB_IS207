<form action="#" method="GET">
    Tên công ty: 
    <select name="tencongty">
        <?php
            include "connect.php";
            $selectedValue = isset($_GET["tencongty"]) ? $_GET["tencongty"] : "";
            $rows = $connect->query("SELECT * FROM CONGTY");
            while($row = $rows->fetch_row()) {
                $selected = ($selectedValue == $row[0]) ? "selected" : "";
                echo "<option value='$row[0]' $selected>".$row[1]."</option>";
            }
            $connect->close();
        ?>
    </select></br>
    <input style="margin: 16px 0; width: 50px; border-radius: 8px" type="submit" name="btn_xoa" value="Xoá">
</form>


<?php
    if(isset($_GET["btn_xoa"]) && $_GET["btn_xoa"] == "Xoá") {
        $maCongTy = $_GET["tencongty"];
        include "connect.php";
        $maChiNhanh = $connect->query("SELECT MaChiNhanh FROM CHINHANH WHERE MaCongTy='$maCongTy'");

        while($maCN = $maChiNhanh->fetch_row()) {
            $maPhongBan = $connect->query("SELECT MaPhong FROM PHONGBAN WHERE MaChiNhanh='$maCN[0]'");
            // Xoá nhân viên của mỗi phòng
            while($maPB = $maPhongBan->fetch_row()) {
                $connect->query("DELETE FROM NHANVIEN WHERE MaPhong='$maPB[0]'");
            }
            // Xoá phòng ban của mỗi chi nhánh
            $connect->query("DELETE FROM PHONGBAN WHERE MaChiNhanh='$maCN[0]'");
        }

        // Xoá chi nhánh của công ty
        $connect->query("DELETE FROM CHINHANH WHERE MaCongTy='$maCongTy'");
        // Xoá công ty
        if($connect->query("DELETE FROM CONGTY WHERE MaCongTy='$maCongTy'") == true) {
            echo "Xoá công ty thành công."."</br>";
        }else {
            echo "Xoá công ty không thành công."."</br>";
        }
        $connect->close();
    }
?>