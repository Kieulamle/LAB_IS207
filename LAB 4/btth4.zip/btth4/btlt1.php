<style>
    body {
        font-size: 18px;
    }

    table {
        width: 200px;
        background-color: #FFC8FF;
        margin: 16px 0;
        font-size: 18px;
    }

    tr:first-child {
        background-color: #C2FFFF;
    }

    input[type="submit"] {
        border-radius: 8px;
    }
</style>

<form action="#" method="GET">
    Tên công ty: 
    <select id="tencongty" name="tencongty" onchange="this.form.submit()">
        <option></option>
        <?php
            include "connect.php";
            $rows = $connect->query("SELECT * FROM CONGTY");
            while($row = $rows->fetch_row()) {
                echo "<option value='$row[0]'>".$row[1]."</option>";
            }
            $connect->close();
        ?>
    </select></br>
    </br>Tên chi nhánh
    <select name="tenchinhanh" id="name">
        <?php
            include "connect.php";
            if(isset($_GET["tencongty"])) {
                $maCongTy = $_GET["tencongty"];
                $rows = $connect->query("SELECT * FROM CHINHANH WHERE MaCongTy='$maCongTy'");
                $listChiNhanh = array();
                while($row = $rows->fetch_row()) {
                    echo "<option value='$row[0]'>".$row[1]."</option>";
                }
            }
            $connect->close();
        ?>
    </select></br></br>
    <input type="submit" name="btn_submit" value="Liệt kê">
</form>

<?php
    if(isset($_GET["btn_submit"]) && $_GET["btn_submit"] == "Liệt kê") {
        include "connect.php";
        $maChiNhanh = $_GET["tenchinhanh"];
        $rows = $connect->query("SELECT * FROM PHONGBAN WHERE MaChiNhanh='$maChiNhanh'");
        $num = 1;

        if($rows->num_rows > 0) {
            echo "Danh sách các phòng ban trong chi nhánh";
            echo "<table border='1' cellspacing='0'><tr><td>STT</td><td>Tên phòng ban</td></tr>";
            while($row = $rows->fetch_row()) {
                echo "<tr><td>$num</td><td>$row[1]</td></tr>";
                $num++;
            }
            echo "</table>";
        }else {
            echo "Không có phòng ban nào trong chi nhánh";
        }
    }
?>

<script>
    document.getElementById('tencongty').value = "<?php echo $_GET['tencongty'];?>";
</script>