<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    table {
        border: 3px solid #C998FF;
        background-color: #FDCCFF;
        width: 350px;
    }

    th, td {
        padding: 4px;
    }

    .title {
        background-color: #CFFFFF;
    }

    input[type="text"] {
        width: 200px;
    }

    input[type="submit"] {
        border-radius: 8px;
    }
</style>
<body>
    <form action="#" method="GET">
        <table>
            <tr>
                <th class="title" colspan="2">Thêm nhân viên</th>
            </tr>
            <tr>
                <td>Tên chi nhánh</td>
                <td>
                    <select name="tenchinhanh" id="name" onchange="this.form.submit()">
                        <?php
                            echo "<option>Chọn chi nhánh</option>";
                            include "connect.php";
                            $rows = $connect->query("SELECT * FROM CHINHANH");
                            $listChiNhanh = array();
                            while($row = $rows->fetch_row()) {
                                echo "<option value='$row[0]'>".$row[1]."</option>";
                            }
                            $connect->close();
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Tên phòng ban</td>
                <td>
                    <select name="tenphongban">
                        <?php
                            if(isset($_GET["tenchinhanh"])) {
                                include "connect.php";
                                $branchName = $_GET["tenchinhanh"];
                                $rows = $connect->query("SELECT * FROM PHONGBAN WHERE MaChiNhanh='$branchName'");
                                $listtenPhongBan = array();
                                while($row = $rows->fetch_row()) {
                                    echo "<option value='$row[0]'>".$row[1]."</option>";
                                }
                                $connect->close();
                            }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Mã nhân viên</td>
                <td><input name="manhanvien" type="text"></td>
            </tr>
            <tr>
                <td>Tên nhân viên</td>
                <td><input name="tennhanvien" type="text"></td>
            </tr>
            <tr>
                <td>Lương</td>
                <td><input name="luong" type="text"></td>
            </tr>
            <tr>
                <td>Giới tính</td>
                <td><input name="gioitinh" type="checkbox"></td>
            </tr>
            <tr>
                <th colspan="2">
                    <input type="submit" name='btn_them' value="Thêm">
                    <input type="submit" name='btn_reset' value="Reset">
                </th>
            </tr>
        </table>
    </form>
    <?php 
        if(isset($_GET["btn_them"]) && $_GET["btn_them"] == "Thêm") {
            $tenPhongBan = $_GET["tenphongban"];
            $maNhanVien = $_GET["manhanvien"];
            $tenNhanVien = $_GET["tennhanvien"];
            $luong = $_GET["luong"];
            $gioiTinh = isset($_GET["luong"]) ? 1 : 0;
            include "connect.php";
            $str = "INSERT INTO NHANVIEN VALUES ('$maNhanVien', '$tenNhanVien', '$luong', '$gioiTinh', '$tenPhongBan')";

            if($connect->query($str) == true) {
                echo "Thêm nhân viên THÀNH CÔNG.";
            }else {
                echo "Thêm nhân viên THẤT BẠI";
            }

            $connect->close();
        }
    ?>
</body>
<script type="text/javascript">
    document.getElementById('name').value = "<?php echo $_GET['tenchinhanh'];?>";
</script>
</html>