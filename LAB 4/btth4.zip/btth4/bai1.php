<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    table {
        border: 3px solid #D392FF;
        background-color: #FFC8FF;
        width: 400px;
        font-size: 18px;
    }
    td {
        font-weight: 580;
    }
    .header {
        background-color: #C2FFFF;
    }

    input[type="submit"] {
        border-radius: 8px;
    }

    input[type="text"] {
        width: 250px;
    }
</style>
<body>
    <form action="#" method="GET">
        <table>
            <tr>
                <td colspan="2" class="header">Thêm công ty</td>
            </tr>
            <tr>
                <td>Mã công ty</td>
                <td><input name="ma" type="text"></td>
            </tr>
            <tr>
                <td>Tên công ty</td>
                <td><input name="ten" type="text"></td>
            </tr>
            <tr>
                <td>Địa chỉ</td>
                <td><input name="diachi" type="text"></td>
            </tr>
            <tr>
                <th colspan="2">
                    <input name="Submit" type="submit" value="Thêm">
                    <input name="Reset" type="submit" value="Reset">
                </th>
            </tr>
        </table>
    </form>
    <?php
        if(isset($_GET['Submit']) && ($_GET['Submit']=="Thêm")) {
            include "connect.php";
            $macongty = $_GET["ma"];
            $tencongty = $_GET["ten"];
            $diachi = $_GET["diachi"];
            $str = "insert into CONGTY values ('$macongty', '$tencongty', '$diachi')";

            if($connect->query($str) == true) {
                echo "Thêm thành công.";
            } else {
                echo "Thêm không thành công.";
            }
            $connect->close();
        }
    ?>
</body>
</html>