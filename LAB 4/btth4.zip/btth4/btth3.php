<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    table {
        border: 3px solid #C998FF;
        background-color: #FDCCFF;
        width: 350px;
    }

    th, td {
        padding: 4px;
    }

    .title {
        background-color: #CFFFFF;
    }

    input[type="text"] {
        width: 200px;
    }

    input[type="submit"] {
        border-radius: 8px;
    }
</style>
<body>
    <form action="#" method="GET">
        <table>
            <tr>
                <th class="title" colspan="2">Thêm phòng ban</th>
            </tr>
            <tr>
                <td>Mã phòng ban</td>
                <td><input name="maphongban" type="text"></td>
            </tr>
            <tr>
                <td>Tên phòng ban</td>
                <td><input name="tenphongban" type="text"></td>
            </tr>
            <tr>
                <td>Tên chi nhánh</td>
                <td>
                    <select name="tenchinhanh">
                        <?php
                            include "connect.php";
                            $rows = $connect->query("SELECT * FROM CHINHANH");
                            $listChiNhanh = array();
                            while($row = $rows->fetch_row()) {
                                if(!in_array($row[1], $listChiNhanh)) {
                                    echo "<option value='$row[0]'>".$row[1]."</option>";
                                    array_push($listChiNhanh, $row[1]);
                                }
                            }
                            $connect->close();
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    <input type="submit" name='btn_them' value="Thêm">
                    <input type="submit" name='btn_reset' value="Reset">
                </th>
            </tr>
        </table>
    </form>
    <?php 
        if(isset($_GET["btn_them"]) && $_GET["btn_them"] == "Thêm") {
            $maPhongBan = $_GET["maphongban"];
            $tenPhongBan = $_GET["tenphongban"];
            $tenChiNhanh = $_GET["tenchinhanh"];
            include "connect.php";
            $str = "INSERT INTO PHONGBAN VALUES ('$maPhongBan', '$tenPhongBan', '$tenChiNhanh')";

            if($connect->query($str) == true) {
                echo "Thêm phòng ban THÀNH CÔNG.";
            }else {
                echo "Thêm phòng ban THẤT BẠI";
            }

            $connect->close();
        }
    ?>
</body>
</html>