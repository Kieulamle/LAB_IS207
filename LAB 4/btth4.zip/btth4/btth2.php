<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    table {
        border: 3px solid #C998FF;
        background-color: #FDCCFF;
        width: 350px;
    }

    th, td {
        padding: 4px;
    }

    .title {
        background-color: #CFFFFF;
    }

    input[type="text"] {
        width: 200px;
    }

    input[type="submit"] {
        border-radius: 8px;
    }
</style>
<body>
    <form action="#" method="GET">
        <table>
            <tr>
                <th class="title" colspan="2">Thêm chi nhánh</th>
            </tr>
            <tr>
                <td>Mã chi nhánh</td>
                <td><input name="machinhanh" type="text"></td>
            </tr>
            <tr>
                <td>Tên chi nhánh</td>
                <td><input name="tenchinhanh" type="text"></td>
            </tr>
            <tr>
                <td>Địa chỉ</td>
                <td><input name="diachi" type="text"></td>
            </tr>
            <tr>
                <td>Tên công ty</td>
                <td>
                    <select name="tencongty">
                        <?php
                            include "connect.php";
                            $rows = $connect->query("SELECT * FROM CONGTY");
                            while($row = $rows->fetch_row()){
                                echo "<option value='$row[0]'>".$row[1]."</option>";
                            }
                            $connect->close();
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th colspan="2">
                    <input type="submit" name='btn_them' value="Thêm">
                    <input type="submit" name='btn_reset' value="Reset">
                </th>
            </tr>
        </table>
    </form>
    <?php 
        if(isset($_GET["btn_them"]) && $_GET["btn_them"] == "Thêm") {
            $maChiNhanh = $_GET["machinhanh"];
            $tenChiNhanh = $_GET["tenchinhanh"];
            $diaChi = $_GET["diachi"];
            $tenCongTy = $_GET["tencongty"];
            include "connect.php";
            $str = "INSERT INTO CHINHANH VALUES ('$maChiNhanh', '$tenChiNhanh', '$diaChi', '$tenCongTy')";

            if($connect->query($str) == true) {
                echo "Thêm chi nhánh THÀNH CÔNG.";
            }else {
                echo "Thêm chi nhánh THẤT BẠI";
            }

            $connect->close();
        }
    ?>
</body>
</html>