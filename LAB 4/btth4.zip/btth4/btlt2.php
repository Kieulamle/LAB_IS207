<form action="#" method="GET">
    <table>
        <tr>
            <th colspan="2">Sửa thông tin chi nhánh</th>
        </tr>
        <tr>
            <td>Tên chi nhánh</td>
            <td>
                <select name="tenchinhanh" id="tenchinhanh" onchange="this.form.submit()">
                    <?php
                        include "connect.php";
                        $rows = $connect->query("SELECT * FROM CHINHANH");
                        $listChiNhanh = array();
                        while($row = $rows->fetch_row()) {
                            echo "<option value='$row[0]'>".$row[1]."</option>";
                        }
                        $connect->close();
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Mã chi nhánh</td>
            <td>
                <?php
                    if(isset($_GET["tenchinhanh"]))  {
                        $machinhanh = $_GET["tenchinhanh"];
                        echo "<input name='machinhanh' value='$machinhanh' type='text' readonly>";
                    }
                ?>
            </td>
        </tr>
        <tr>
            <td>Tên chi nhánh</td>
            <td>
                <input type="text" name="tenchinhanh_moi">
            </td>
        </tr>
        <tr>
            <td>Địa chỉ</td>
            <td>
                <input type="text" name="diachi">
            </td>
        </tr>
        <tr>
            <td>
                Tên công ty
            </td>
            <td>
                <select id="tencongty" name="tencongty">
                    <?php
                        include "connect.php";
                        $rows = $connect->query("SELECT * FROM CONGTY");
                        while($row = $rows->fetch_row()) {
                            echo "<option value='$row[0]'>".$row[1]."</option>";
                        }
                        $connect->close();
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <th colspan="2">
                <input type="submit" name="btn_update" value="Cập nhập">
            </th>
        </tr>
    </table>
</form>

<?php
    if(isset($_GET["btn_update"]) && $_GET["btn_update"] == "Cập nhập") {
        $maChiNhanh = $_GET["tenchinhanh"];
        $tenChiNhanhMoi = $_GET["tenchinhanh_moi"];
        $diaChi = $_GET["diachi"];
        $maCongTy = $_GET["tencongty"];
        include "connect.php";
        $str = "UPDATE CHINHANH SET TenChiNhanh='$tenChiNhanhMoi', DiaChi='$diaChi', MaCongTy='$maCongTy' WHERE MaChiNhanh='$maChiNhanh'";

        if($connect->query($str) == true) {
            echo "Cập nhập chi nhánh thành công.";
        }else {
            echo "Cập nhập chi nhánh thất bại.";
        }
    }
?>

<style>
    table {
        width: 400px;
        background-color: #FFC8FF;
        font-size: 18px;
    }

    tr:first-child {
        background-color: #C2FFFF;
    }

    th, td {
        padding: 4px 0;
    }

    input[type="submit"] {
        border-radius: 8px;
    }
</style>

<script>
    document.getElementById('tenchinhanh').value = "<?php echo $_GET['tenchinhanh'];?>";
</script>