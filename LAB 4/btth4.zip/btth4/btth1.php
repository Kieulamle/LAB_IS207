<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ex 5 - Cập nhập nhân viên</title>

    <style>
        table, tr, td{
            border: 1px solid black;
            border-collapse: collapse;
        }

        table tr:last-child{
            text-align: center;
        }
    </style>
</head>

<?php
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    include '../connect.php';


    $sql = "SELECT * FROM NHANVIEN WHERE MaNhanVien='$id'";
    $result = $connect->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id = $row['MaNhanVien'];
        $name = $row['TenNhanVien'];
        $salary = $row['LuongThang'];
        $sex = $row['GioiTinh'];
        $department = $row['MaPhong'];
    } else {
        // Xử lý lỗi hoặc thông báo nếu không có dữ liệu
        // echo "Không có dữ liệu hoặc có lỗi trong truy vấn.";
        $name = $salary = $sex = $department = "";
    }

    $connect->close();
?>

<body>
    <table>
    <form method="GET">
        <tr>
            <td>Mã nhân viên</td>
            <td><input  type="text" name="id_" value="<?php echo $id; ?>" readonly></td>
        </tr>

        <tr>
            <td>Tên nhân viên</td>
            <td><input type="text" name="name" value="<?php echo $name ;?>"></td>
        </tr>

        <tr>
            <td>Lương tháng</td>
            <td><input type="text" name="salary" value="<?php echo $salary; ?>"></td>
        </tr>

        <tr>
            <td>Giới tính</td>
            <td><input type="text" name="sex" value="<?php echo $sex; ?>"></td>
        </tr>

        <tr>
            <td>Mã phòng ban</td>
            <td>
                <select name="department">
                    <?php
                        include '../connect.php';
                        $sql = "SELECT * FROM PHONGBAN";
                        $result = $connect->query($sql);

                         if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                if ($row['MaPhong'] == $department) {
                                    echo "<option value='" . $row['MaPhong'] . "' selected>" . $row['MaPhong'] . "</option>";
                                } else {
                                    echo "<option value='" . $row['MaPhong'] . "'>" . $row['MaPhong'] . "</option>";
                                }
                            }
                        }
                        $connect->close();
                    ?>
                </select>
            </td>
        </tr>

        <tr>
            <td colspan='2'>
                <input type="submit" value="Cập nhập" name="update">
            </td>
        </tr>
    </form>
    </table>
</body>
</html>


<?php
    if(isset($_GET['update'])){
        include '../connect.php';

        $id = $_GET['id_']; 
        $name_update = $_GET['name'];
        $salary_update = $_GET['salary'];
        $sex_update = $_GET['sex'];
        $department_update = $_GET['department'];

        $sql = "UPDATE NHANVIEN SET TenNhanVien='$name_update', LuongThang='$salary_update', GioiTinh='$sex_update', MaPhong='$department_update' WHERE MaNhanVien='$id'";

        if ($connect->query($sql) === TRUE) {
            echo "Cập nhập thành công";
        } else {
            echo "Cập nhập thất bại: " . $connect->error;
        }

        $connect->close();
    }
?>