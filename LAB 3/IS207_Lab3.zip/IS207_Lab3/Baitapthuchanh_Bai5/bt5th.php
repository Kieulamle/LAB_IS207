<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chương trình cộng, trừ, nhân, chia hai phân số</title>
    <style>
        table {
            width: 80%;
            height: 200px;
            border-collapse: collapse;
            background-color: #CBCCFF;
            margin: 20px;
            margin-left: auto;
            margin-right: auto;
        }

        table, th, td {
            border: 2px solid #C76DFF;
        }

        th, td {
            padding: 12px;
            line-height: 2;
            vertical-align: top;
            background-color: #CBCCFF;
            border-color: #C76DFF;
        }

        h2 {
            text-align: center;
            color: #210AFF;
        }

        .submit-button {
            border-radius: 15px;
            width: 80px;
        }

        .container {
            display: block;
            margin: 10px;
            line-height: 1.5;
            margin-bottom: 50px;
            width: 200px;
            border: 2px solid #909091;
            margin-left: auto;
            margin-right: auto;
        }

        .container input {
            margin-right: 10px;
        }

        .container::before {
            content: "Phép tính";
            position: absolute;
            top: 69px;
            left: 450px;
            z-index: 1;
            background-color: #CBCCFF;
        }
    </style>
</head>
<body>
    <?php
    class PhanSo
    {
        private $tu;
        private $mau;
    
        public function __construct($tu, $mau)
        {
            $this->tu = $tu;
            $this->mau = $mau;
        }
    
        public function getTu()
        {
            return $this->tu;
        }
    
        public function getMau()
        {
            return $this->mau;
        }
    
        public function cong(PhanSo $ps)
        {
            $tuMoi = $this->tu * $ps->mau + $ps->tu * $this->mau;
            $mauMoi = $this->mau * $ps->mau;
    
            return new PhanSo($tuMoi, $mauMoi);
        }
    
        public function tru(PhanSo $ps)
        {
            $tuMoi = $this->tu * $ps->mau - $ps->tu * $this->mau;
            $mauMoi = $this->mau * $ps->mau;
    
            return new PhanSo($tuMoi, $mauMoi);
        }
    
        public function nhan(PhanSo $ps)
        {
            $tuMoi = $this->tu * $ps->tu;
            $mauMoi = $this->mau * $ps->mau;
    
            return new PhanSo($tuMoi, $mauMoi);
        }
    
        public function chia(PhanSo $ps)
        {
            $tuMoi = $this->tu * $ps->mau;
            $mauMoi = $this->mau * $ps->tu;
    
            return new PhanSo($tuMoi, $mauMoi);
        }
    
        public function donGian()
        {
            if ($this->mau == 1) {
                return new PhanSo($this->tu, 1);
            }

            $ucln = $this->timUCLN($this->tu, $this->mau);
            $tuMoi = $this->tu / $ucln;
            $mauMoi = $this->mau / $ucln;

            return new PhanSo($tuMoi, $mauMoi);
        }
    
        private function timUCLN($a, $b)
        {
            while ($b != 0) {
                $remainder = $a % $b;
                $a = $b;
                $b = $remainder;
            }
            return abs($a);
        }
    }    

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $tu1 = $_POST['tu1'];
        $mau1 = $_POST['mau1'];
        $tu2 = $_POST['tu2'];
        $mau2 = $_POST['mau2'];

        $ps1 = new PhanSo($tu1, $mau1);
        $ps2 = new PhanSo($tu2, $mau2);

        $phepTinh = $_POST['phepTinh'];
        $ketQua = null;

        switch ($phepTinh) {
            case 'cong':
                $ketQua = $ps1->cong($ps2)->donGian();
                $ketQuaString = "Tổng" . ' ' . $tu1 . '/' . $mau1 . ' ' . "+" . ' ' . $tu2 . '/' . $mau2 . ' = ' . $ketQua->getTu() . '/' . $ketQua->getMau();
                break;
            case 'tru':
                $ketQua = $ps1->tru($ps2)->donGian();
                $ketQuaString = "Hiệu" . ' ' . $tu1 . '/' . $mau1 . ' ' . "-" . ' ' . $tu2 . '/' . $mau2 . ' = ' . $ketQua->getTu() . '/' . $ketQua->getMau();
                break;
            case 'nhan':
                $ketQua = $ps1->nhan($ps2)->donGian();
                $ketQuaString = "Tích" . ' ' . $tu1 . '/' . $mau1 . ' ' . "*" . ' ' . $tu2 . '/' . $mau2 . ' = ' . $ketQua->getTu() . '/' . $ketQua->getMau();
                break;
            case 'chia':
                $ketQua = $ps1->chia($ps2)->donGian();
                $ketQuaString = "Thương" . ' ' . $tu1 . '/' . $mau1 . ' ' . ":" . ' ' . $tu2 . '/' . $mau2 . ' = ' . $ketQua->getTu() . '/' . $ketQua->getMau();
                break;
        }
    }
    ?>

    <h2>Chương trình cộng, trừ, nhân, chia hai phân số</h2>
    <form method="post" action="">
        <table>
            <tr>
            <td>
                <div>
                    Tử phân số 1 <input type="text" name="tu1"/>
                </div>
                <div>
                    Mẫu phân số 1 <input type="text" name="mau1"/>
                </div>

                <div>
                    Tử phân số 2 <input type="text" name="tu2"/>
                </div>
                <div>
                    Mẫu phân số 2 <input type="text" name="mau2"/>
                </div>
                <div>
                    <button type="submit" name="submit" class="submit-button">=</button>
                </div>
                <div>
                    <?php if (isset($ketQuaString)): ?>
                    <p><?php echo $ketQuaString; ?></p>
                    <?php endif; ?> 
                </div>
            </td>
            <td class="container">
                 <div>
                        <input type="radio" id="cong" name="phepTinh" value="cong" checked>
                        <label for="cong">+</label>
                    </div>
                    <div>
                        <input type="radio" id="tru" name="phepTinh" value="tru">
                        <label for="tru">-</label>
                    </div>
                    <div>
                        <input type="radio" id="nhan" name="phepTinh" value="nhan">
                        <label for="nhan">*</label>
                    </div>
                    <div>
                        <input type="radio" id="chia" name="phepTinh" value="chia">
                        <label for="chia">/</label>
                    </div>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>
