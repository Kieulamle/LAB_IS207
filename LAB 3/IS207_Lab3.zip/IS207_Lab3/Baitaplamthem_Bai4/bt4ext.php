<?php

class TaiKhoan
{
    private $soTK;
    private $tenTK;
    private $soTien;

    public function __construct($soTK = 0, $tenTK = "", $soTien = 10.0)
    {
        $this->soTK = $soTK;
        $this->tenTK = $tenTK;
        $this->soTien = $soTien;
    }

    public function getSoTK()
    {
        return $this->soTK;
    }

    public function getTenTK()
    {
        return $this->tenTK;
    }

    public function getSoTien()
    {
        return $this->soTien;
    }

    public function InTaiKhoan()
    {
        echo "Thông tin tài khoản:<br>";
        echo "Số tài khoản: {$this->soTK}<br>";
        echo "Tên tài khoản: {$this->tenTK}<br>";
        echo "Số tiền trong tài khoản: $" . number_format($this->soTien, 2) . "<br>";
    }

    public function NapTien($st)
    {
        if ($st > 0) {
            $this->soTien += $st;
            return true;
        } else {
            echo "Số tiền nạp vào phải lớn hơn 0.<br>";
            return false;
        }
    }

    public function RutTien($st)
    {
        if ($st > 0 && $st + $st * 0.01 <= $this->soTien) {
            $this->soTien -= ($st + $st * 0.01);
            return true;
        } else {
            echo "Số tiền rút không hợp lệ hoặc không đủ tiền trong tài khoản.<br>";
            return false;
        }
    }
}

// Sử dụng lớp TaiKhoan
$tk = new TaiKhoan(123456, "John Doe");

$tk->InTaiKhoan();

$tk->NapTien(50);
$tk->InTaiKhoan();

$tk->RutTien(15);
$tk->InTaiKhoan();

?>
