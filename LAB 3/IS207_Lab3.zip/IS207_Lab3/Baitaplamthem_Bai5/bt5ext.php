<?php

class Sach
{
    protected $maSach;
    protected $tenSach;
    protected $donGia;
    protected $soLuong;
    protected $nhaXuatBan;

    public function __construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan)
    {
        $this->maSach = $maSach;
        $this->tenSach = $tenSach;
        $this->donGia = $donGia;
        $this->soLuong = $soLuong;
        $this->nhaXuatBan = $nhaXuatBan;
    }

    public function tinhThanhTien()
    {
        return $this->soLuong * $this->donGia;
    }
}

class SachTieuThuyet extends Sach
{
    private $tinhTrang;

    public function __construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan, $tinhTrang)
    {
        parent::__construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan);
        $this->tinhTrang = $tinhTrang;
    }

    public function tinhThanhTien()
    {
        if ($this->tinhTrang == 1) {
            return parent::tinhThanhTien();
        } elseif ($this->tinhTrang == 2) {
            return parent::tinhThanhTien() * 0.2;
        }
    }
}

class SachTrinhTham extends Sach
{
    private $thue;

    public function __construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan, $thue)
    {
        parent::__construct($maSach, $tenSach, $donGia, $soLuong, $nhaXuatBan);
        $this->thue = $thue;
    }

    public function tinhThanhTien()
    {
        return parent::tinhThanhTien() + $this->thue;
    }
}

$sachTieuThuyet = new SachTieuThuyet('001', 'Bắt trẻ đồng xanh', 10, 5, 'NXB A', 1);

$sachTrinhTham = new SachTrinhTham('002', 'Kỳ án ánh trăng', 15, 3, 'NXB B', 2);

$danhSachSach = [$sachTieuThuyet, $sachTrinhTham];

$countSachTieuThuyet = 0;
$countSachTrinhTham = 0;

foreach ($danhSachSach as $sach) {
    if ($sach instanceof SachTieuThuyet) {
        $countSachTieuThuyet++;
    } elseif ($sach instanceof SachTrinhTham) {
        $countSachTrinhTham++;
    }
}

echo "Số lượng Sách Tiểu Thuyết: $countSachTieuThuyet<br>";
echo "Số lượng Sách Trinh Thám: $countSachTrinhTham<br>";

$tongTienSachTieuThuyet = 0;
$tongTienSachTrinhTham = 0;

foreach ($danhSachSach as $sach) {
    if ($sach instanceof SachTieuThuyet) {
        $tongTienSachTieuThuyet += $sach->tinhThanhTien();
    } elseif ($sach instanceof SachTrinhTham) {
        $tongTienSachTrinhTham += $sach->tinhThanhTien();
    }
}

echo "Tổng tiền Sách Tiểu Thuyết: $tongTienSachTieuThuyet<br>";
echo "Tổng tiền Sách Trinh Thám: $tongTienSachTrinhTham<br>";

?>
