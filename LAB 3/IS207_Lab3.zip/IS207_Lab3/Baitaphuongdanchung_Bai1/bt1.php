<!DOCTYPE html>
<html>
    <head>
        <title>Hình chữ nhật</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <style>
            table, th, td
            {
                width: 70%;
                font-weight: bold;
                border: 3px solid #cc00ff;
                background-color: #c57993;
            }

            table
            {
                margin: 0 auto;
                width: 40%;
                border-collapse: collapse;
            }

            .Tinh
            {
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
        <?php 
            $Dai = $Rong = $DT = $CV = "";

            if (isset($_POST['Submit']) && ($_POST['Submit'] == "Tính"))
            {
                $Dai = $_POST['Dai'];
                $Rong = $_POST['Rong'];
                $DT = (float)$Dai * (float)$Rong;
                $CV = ((float)$Dai + (float)$Rong) * 2;
            }
        ?>

        <div class="table">
            <h2 style="color: blue" align="center">Tính diện tích và chu vi hình chữ nhật</h2>
            <form method="POST" action="#">
                <table>
                    <tr>
                        <td>Chiều dài</td>
                        <td><input type="number" min="0" name="Dai"></td>
                    </tr>
                    <tr>
                        <td>Chiều rộng</td>
                        <td><input type="number" min="0" name="Rong"></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="2"><button name="Submit" class="Tinh" value="Tính">Tính</button></td>
                    </tr>
                </table>
            </form>
        
            <div align="center">
                <?php
                    echo "Diện tích=".$DT."<br>";
                    echo "Chu vi=".$CV."<br>";
                ?>
            </div>
        </div>
    </body>
</html>