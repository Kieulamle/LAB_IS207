<!DOCTYPE html>
<html>
    <head>
        <title>Hình chữ nhật</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <style>
            table, th, td
            {
                border: 3px solid #cc00ff;
                background-color: #c57993;
                width: 30%;
            }

            table
            {
                margin: 0 auto;
                width: 30%;
                border-collapse: collapse;
            }

            .Tinh
            {
                border-radius: 10px;
            }
        </style>
    <body>
        <?php
        class Hinhchunhat
        {
            private $dai;
            private $rong;

            public function __construct($dai, $rong)
            {
                $this->dai = $dai;
                $this->rong = $rong;
            }

            public function Dientich()
            {
                return $this->dai * $this->rong;
            }

            public function Chuvi()
            {
                return ($this->dai + $this->rong) * 2;
            }
        }
        
        $c = new Hinhchunhat(0,0);

        if (isset($_POST['Submit']) && ($_POST['Submit'] == "Tính"))
        {
            $c = new Hinhchunhat($_POST['Dai'], $_POST['Rong']);
        }
        ?>

        <div class="table">
            <h2 style="color: blue" align="center">Tính diện tích và chu vi hình chữ nhật</h2>
            <form method="POST" action="#">
                <table>
                    <tr>
                        <td>Chiều dài</td>
                        <td><input type="number" min="0" name="Dai"></td>
                    </tr>
                    <tr>
                        <td>Chiều rộng</td>
                        <td><input type="number" min="0" name="Rong"></td>
                    </tr>
                    <tr>
                        <td align="center" colspan="2"><button name="Submit" class="Tinh" value="Tính">Tính</button></td>
                    </tr>
                </table>
            </form>
        
            <div align="center">
                <?php
                    echo "Diện tích = ".$c->Dientich()."<br>";
                    echo "Chu vi = ".$c->Chuvi()."<br>";
                ?>
            </div>
        </div>
    </body>
</html>