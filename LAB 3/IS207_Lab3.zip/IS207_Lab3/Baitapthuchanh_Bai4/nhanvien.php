<?php

class NhanVien
{
    private $maNV;
    private $tenNV;
    private $soNgayLam;
    private $luongNgay;

    public function Gan($ma, $ten, $soNgay, $luongNgay)
    {
        $this->maNV = $ma;
        $this->tenNV = $ten;
        $this->soNgayLam = $soNgay;
        $this->luongNgay = $luongNgay;
    }

    public function InNhanVien()
    {
        echo "Thông tin nhân viên:<br>";
        echo "Mã nhân viên: {$this->maNV}<br>";
        echo "Tên nhân viên: {$this->tenNV}<br>";
        echo "Số ngày làm trong tháng: {$this->soNgayLam}<br>";
        echo "Lương ngày: {$this->luongNgay}<br>";
    }

    public function TinhLuong()
    {
        return $this->soNgayLam * $this->luongNgay;
    }
}

class NhanVienQL extends NhanVien
{
    private $phuCap = 2000;

    public function InNhanVien()
    {
        parent::InNhanVien();
        echo "Phụ cấp: {$this->phuCap}<br>";
    }

    public function TinhLuong()
    {
        return parent::TinhLuong() + $this->phuCap;
    }
}

?>
