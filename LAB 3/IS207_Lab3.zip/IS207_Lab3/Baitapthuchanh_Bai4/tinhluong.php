<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tính lương tháng</title>
    <style>
        table {
            width: 60%;
            height: 200px;
            font-weight: bold;
            border-collapse: collapse;
            background-color: #FC9A00;
            margin: 20px;
            margin-left: auto;
            margin-right: auto;
        }

        th, td {
            padding: 12px;
            line-height: 2;
            vertical-align: top;
            background-color: #FC9A00;
        }

        .container {
            display: flex;
            flex-direction: column;
            width: 90%;
        }

        .container div {
            display: flex; /* Thêm thuộc tính flex */
            justify-content: space-between; /* Canh giữa các textfield */
            width: 95%; /* Đảm bảo textfield căn đều trong div */
            margin-bottom: 5px;
            align-items: center; /* Khoảng cách giữa các div */
        }

        .checkbox-container {
            display: flex;
            align-items: center;
        }

        .checkbox-container input[type="checkbox"] {
             margin-right: 155px; /* Khoảng cách giữa checkbox và textfield */
        }

        button {
            border-radius: 8px; /* Điều chỉnh giá trị theo ý muốn của bạn */
        }
        </style>
</head>
<body>
    <form method="post" action="" class="container">
        <table>
            <tr>
                <td>
                <div>
                        <span>Mã nhân viên</span>
                        <input type="text" name="maNV">
                    </div>
                
                    <div>
                        <span>Tên nhân viên</span>
                        <input type="text" name="tenNV">
                    </div>
            
                    <div>
                        <span>Số ngày làm trong tháng</span>
                        <input type="text" name="soNgayLam">
                    </div>
            
                    <div>
                        <span>Lương ngày</span>
                        <input type="text" name="luongNgay">
                    </div>
            
                    <div class="checkbox-container">
                        <span>Nhân viên quản lý</span>
                        <input type="checkbox" name="isQuanLy">
                    </div>
            
                    <div colspan="2">
                        <button type="submit">Lương tháng</button>
                    </div>
                </td>   
            </tr>
        </table>
    </form>
</body>
</html>

<?php

include 'nhanvien.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $maNV = $_POST['maNV'];
    $tenNV = $_POST['tenNV'];
    $soNgayLam = $_POST['soNgayLam'];
    $luongNgay = $_POST['luongNgay'];
    $isQuanLy = isset($_POST['isQuanLy']);

    if ($isQuanLy) {
        $nhanVien = new NhanVienQL();
    } else {
        $nhanVien = new NhanVien();
    }

    $nhanVien->Gan($maNV, $tenNV, $soNgayLam, $luongNgay);

    $luongThang = $nhanVien->TinhLuong();

    $nhanVien->InNhanVien();

    echo "Lương tháng: $luongThang<br>";
}

?>
