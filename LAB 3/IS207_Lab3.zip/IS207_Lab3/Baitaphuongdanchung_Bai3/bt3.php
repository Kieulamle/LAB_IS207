<!DOCTYPE html>
<html>
    <head>
        <title>Tìm tên</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <body>
        <div>
            <form method="GET" action="#">
                Nhập tên cần tìm <input type="input" name="Ten"><br>
                <button name="Submit" value="Tìm">Tìm</button>
            </form>

            <?php
                $Ten = "";
                $ban = array("Tuấn"=>21, "Tú"=>19, "Tâm"=>22, "Tùng"=>20);

                function Timkiem($ban, $Ten)
                {
                    foreach($ban as $temp=>$tuoi)
                    {
                        if($temp == $Ten)
                        {
                            return true;
                        }
                    }
                    return false;
                }

                if (isset($_GET['Submit']) && ($_GET['Submit'] == "Tìm"))
                {
                    $Ten = $_GET["Ten"];
                    $Kiemtra = Timkiem($ban, $Ten);

                    if($Kiemtra)
                    {
                        echo "Tìm thấy ".$Ten." trong mảng <br>";
                    }
                    else
                    {
                        echo "Không tìm thấy ".$Ten." trong mảng <br>";
                    }

                    echo "<b>Xuất mảng</b><br>";
                    foreach($ban as $temp=>$tuoi)
                    {
                        echo $temp." ".$tuoi;
                        echo "<br>";
                    }
                }
            ?>
        </div>
    </body>
</html>