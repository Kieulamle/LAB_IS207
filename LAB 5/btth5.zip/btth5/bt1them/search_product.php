<?php
$servername = "localhost";
$username = "root";
$password = "";
$DBName = "qlsp";

$conn = new mysqli($servername, $username, $password, $DBName);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

if (isset($_GET['query'])) {
    $query = $_GET['query'];

    // Thực hiện truy vấn tìm kiếm sản phẩm
    $sql = "SELECT * FROM SANPHAM WHERE TENSP LIKE '%$query%'";
    $result = $conn->query($sql);

    if ($result === false) {
        // Xử lý lỗi truy vấn SQL
        echo "Lỗi truy vấn: " . $conn->error;
    } else {
        // Kiểm tra số lượng hàng trả về
        if ($result->num_rows > 0) {
            // Hiển thị kết quả tìm kiếm
            while ($row = $result->fetch_assoc()) {
                echo '<div>' . $row['TENSP'] . '</div>';
            }
        } else {
            echo '<div>Không tìm thấy sản phẩm</div>';
        }
    }
}

$conn->close();
?>
