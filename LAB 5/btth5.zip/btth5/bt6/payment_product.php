<?php
    $servername = "localhost";
    $username = "root";
    $password ="";
    $DBName = "qlsp";

    $conn = new mysqli($servername, $username, $password, $DBName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    session_start();
    $totalMoneyProducts = 0;
    $html = '';

    foreach($_SESSION["my_cart"] as $key => $value) {
        $row = $conn->query("SELECT * FROM SANPHAM WHERE MASP='$key'")->fetch_row();

        $totalMoney = $row[4]*$value['productQnt'];
        $totalMoneyProducts += $totalMoney;
        $html .= "
            <tr>
                <td class='product-name'>
                    <span>$row[1]<span>
                </td>
                <td class='product-qnt'>
                    <span>$value[productQnt]</span>
                </td>
                <td class='product-total'>$totalMoney</td>
            </tr>
        ";
    }

    $html .= "|".$totalMoneyProducts;
    echo($html);
?>