<?php
    $servername = "localhost";
    $username = "root";
    $password ="";
    $DBName = "qlsp";

    $conn = new mysqli($servername, $username, $password, $DBName);

    if ($conn->connect_error) {
        die("Kết nối thất bại: " . $conn->connect_error);
    }

    $category = $_GET['category'];

    if ($category === 'all') {
        $sql = "SELECT * FROM sanpham";
    } else {
        $sql = "SELECT * FROM sanpham WHERE LOAISP = '$category'";
    }
    
    $rows = $conn->query($sql);
    
    while($row = $rows->fetch_row()) {
        echo "
        <div class='product'>
            <div class='product__img'>
                <img src='$row[5]' />
            </div>
            <div class='product__info'>
                <span>$row[1]</span>
                <span>Don vi tinh: $row[2]</span>
                <span>Gia: $row[4]</span>
            </div>
            <div class='product__qnt'>
                <span>So luong:</span>
                <input class='product__qnt-input' type='number' value='1'>
                <button MaSP='$row[0]' class='product__btn-add'>Chọn mua</button>
            </div>
        </div>
        ";
    }
?>
