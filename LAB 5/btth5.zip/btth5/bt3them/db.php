<?php
$servername = "localhost";
$username = "root";
$password = "";
$DBName = "qlsp";

$conn = new mysqli($servername, $username, $password, $DBName);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

mysqli_set_charset($conn, 'UTF8');

if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['SOHD'])) {
    $SOHD_to_delete = $_GET['SOHD'];
    $delete_sql = "DELETE FROM HOADON WHERE SOHD = $SOHD_to_delete";
    $result = $conn->query($delete_sql);

    if ($result) {
        echo "Xóa đơn hàng thành công";
    } else {
        echo "Lỗi khi xóa đơn hàng: " . $conn->error;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $sohd_to_edit = $_POST['sohd'];
    $new_hotenkh = $_POST['hotenkh'];
    $new_sdt = $_POST['sdt'];
    $new_email = $_POST['email'];
    $new_diachi = $_POST['diachi'];

    $edit_sql = "UPDATE hoadon SET hotenkh = '$new_hotenkh', sdt = '$new_sdt', email = '$new_email', diachi = '$new_diachi' ";
    $edit_sql .= " WHERE sohd = $sohd_to_edit";
    $conn->query($edit_sql);
}

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$items_per_page = 3;
$offset = ($page - 1) * $items_per_page;

$sohd = isset($_GET['sohd']) ? $_GET['sohd'] : null;

$sql = "SELECT * FROM hoadon";
if ($sohd){
    $sql .= " WHERE sohd = $sohd";
}
$result = $conn->query($sql);

$total_sql = "SELECT COUNT(*) AS count FROM hoadon";
$total_result = $conn->query($total_sql);
$total_count = $total_result->fetch_assoc()['count'];
$total_pages = ceil($total_count / $items_per_page);

$data = array();
while ($row = $result->fetch_assoc()) {
    array_push($data, $row);
}

$response = array(
    'orders' => $data,
    'total_pages' => $total_pages
);

echo json_encode($response); 
$conn->close();
?>
