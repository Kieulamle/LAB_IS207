<?php
$servername = "localhost";
$username = "root";
$password = "";
$DBName = "qlsp";

$conn = new mysqli($servername, $username, $password, $DBName);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

mysqli_set_charset($conn, 'UTF8');

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$items_per_page = 3;
$offset = ($page - 1) * $items_per_page;

$sql = "SELECT * FROM SANPHAM LIMIT $offset, $items_per_page";
$result = $conn->query($sql);

$total_sql = "SELECT COUNT(*) AS count FROM SANPHAM";
$total_result = $conn->query($total_sql);
$total_count = $total_result->fetch_assoc()['count'];
$total_pages = ceil($total_count / $items_per_page);

$data = array();
while ($row = $result->fetch_assoc()) {
    array_push($data, $row);
}

$response = array(
    'products' => $data,
    'total_pages' => $total_pages
);

echo json_encode($response); 
$conn->close();
?>
