<?php
$servername = "localhost";
$username = "root";
$password = "";
$DBName = "qlsp";

$conn = new mysqli($servername, $username, $password, $DBName);

if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

$idProduct = $_GET['idProduct'];
$nameProduct = $_GET['nameProduct'];
$country = $_GET['country'];
$unit = $_GET['unit'];
$price = $_GET['price'];
$type = $_GET['type'];
$linkImage = $_GET['linkImage'];

$isSuccess = $conn->query("INSERT INTO SANPHAM VALUES ('$idProduct', '$nameProduct', '$unit', '$country', $price, '$linkImage', '$type')");

if($isSuccess == true) {
    echo "Thêm sảm phẩm THÀNH CÔNG";
} else {
    echo "Thêm sản phẩm THẤT BẠI";
}
?>
