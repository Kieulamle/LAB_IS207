<?php
    $servername = "localhost";
    $username = "root";
    $password ="";
    $DBName = "qlsp";

    $conn = new mysqli($servername, $username, $password, $DBName);

    if ($conn->connect_error) {
        die("Kết nối thất bại: " . $conn->connect_error);
    }

    $category = $_GET['category'];

    if ($category === 'all') {
        $sql = "SELECT * FROM sanpham";
    } else {
        $sql = "SELECT * FROM sanpham WHERE LOAISP = '$category'";
    }
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // Hiển thị danh sách sản phẩm
        while ($row = $result->fetch_assoc()) {
            echo '<div class="product">';
            echo '<div class="product__img"><img src="' . $row['HINHANH'] . '" alt="' . $row['TENSP'] . '"></div>';
            echo '<div class="product__info">';
            echo '<span>' . $row['TENSP'] . '</span>';
            echo '<span>Đơn vị tính: ' . $row['DVT'] . '</span>';
            echo '<span>Giá: ' . $row['GIA'] . '</span>';
            echo '<div class="product__qnt">';
            echo '<span>Số lượng: <input type="number" id="quantity_' . $row['MASP'] . '" value="1" min="1">';
            echo '<button class="product__btn-add" data-masp="' . $row['MASP'] . '" data-tensp="' . $row['TENSP'] . '" data-gia="' . $row['GIA'] . '">Chọn mua</button>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo 'Không có sản phẩm nào.';
    }
    $conn->close();
?>
